import { openDB } from 'idb';

const DB_NAME = 'aligner-tracker-db';
const DB_VERSION = 1;

export const initDB = async () => {
  return openDB(DB_NAME, DB_VERSION, {
    upgrade(db) {
      // Store for app settings (current cycle, start date, appointment, etc.)
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings');
      }
      // Store for daily photos
      if (!db.objectStoreNames.contains('photos')) {
        const photoStore = db.createObjectStore('photos', { keyPath: 'id', autoIncrement: true });
        photoStore.createIndex('date', 'date', { unique: false });
      }
    },
  });
};

export const getSettings = async () => {
  const db = await initDB();
  const settings = {};
  const keys = ['startDate', 'currentCycle', 'nextAppointment', 'cycleDuration'];
  for (const key of keys) {
    settings[key] = await db.get('settings', key);
  }
  return settings;
};

export const saveSetting = async (key, value) => {
  const db = await initDB();
  await db.put('settings', value, key);
};

export const addPhoto = async (photoData) => {
  // photoData: { date: 'YYYY-MM-DD', type: 'wearing' | 'not-wearing', blob: Blob/Base64 }
  const db = await initDB();
  return db.add('photos', photoData);
};

export const getPhotosByDate = async (date) => {
  const db = await initDB();
  return db.getAllFromIndex('photos', 'date', date);
};

export const getAllPhotos = async () => {
  const db = await initDB();
  return db.getAll('photos');
};

export const deletePhoto = async (id) => {
  const db = await initDB();
  return db.delete('photos', id);
};
