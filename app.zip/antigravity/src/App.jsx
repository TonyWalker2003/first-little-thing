import { useState, useEffect } from 'react';
import './App.css';
import { getSettings, saveSetting, addPhoto, getPhotosByDate, deletePhoto, getAllPhotos, initDB } from './db';

function App() {
  const [loading, setLoading] = useState(true);
  const [settings, setSettings] = useState(null);
  const [view, setView] = useState('dashboard');

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    const data = await getSettings();
    if (data.startDate) {
      setSettings(data);
    }
    setLoading(false);
  };

  const handleSetup = async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const newSettings = {
      startDate: formData.get('startDate'),
      cycleDuration: parseInt(formData.get('cycleDuration')),
      currentCycle: parseInt(formData.get('currentCycle')),
      nextAppointment: formData.get('nextAppointment'),
    };

    for (const [key, value] of Object.entries(newSettings)) {
      await saveSetting(key, value);
    }
    setSettings(newSettings);
  };

  if (loading) return <div className="loading">Loading...</div>;

  if (!settings) {
    return (
      <div className="card">
        <div className="header">
          <h1>歡迎使用牙套日記</h1>
          <p>請先設定您的矯正資訊</p>
        </div>
        <form onSubmit={handleSetup}>
          <div className="form-group">
            <label>開始矯正日期</label>
            <input type="date" name="startDate" required defaultValue={new Date().toISOString().split('T')[0]} />
          </div>
          <div className="form-group">
            <label>每副牙套配戴天數</label>
            <input type="number" name="cycleDuration" required defaultValue="7" min="1" />
          </div>
          <div className="form-group">
            <label>目前配戴第幾副</label>
            <input type="number" name="currentCycle" required defaultValue="1" min="1" />
          </div>
          <div className="form-group">
            <label>下次複診日期</label>
            <input type="date" name="nextAppointment" required />
          </div>
          <button type="submit" className="btn">開始紀錄</button>
        </form>
      </div>
    );
  }

  return (
    <div>
      {view === 'dashboard' && <Dashboard settings={settings} />}
      {view === 'history' && <HistoryView />}
      {view === 'settings' && <SettingsView settings={settings} />}

      <div style={{ height: '80px' }}></div>

      <nav className="nav">
        <a href="#" className={`nav-item ${view === 'dashboard' ? 'active' : ''}`} onClick={() => setView('dashboard')}>主頁</a>
        <a href="#" className={`nav-item ${view === 'history' ? 'active' : ''}`} onClick={() => setView('history')}>歷史</a>
        <a href="#" className={`nav-item ${view === 'settings' ? 'active' : ''}`} onClick={() => setView('settings')}>設定</a>
      </nav>
    </div>
  );
}

function Dashboard({ settings }) {
  const [photos, setPhotos] = useState([]);
  const todayStr = new Date().toISOString().split('T')[0];

  useEffect(() => {
    loadPhotos();
  }, []);

  const loadPhotos = async () => {
    const data = await getPhotosByDate(todayStr);
    setPhotos(data);
  };

  const today = new Date();
  const nextAppt = new Date(settings.nextAppointment);
  const diffTime = nextAppt - today;
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  const handleFileUpload = async (e, type) => {
    const file = e.target.files[0];
    if (!file) return;

    const photoData = {
      date: todayStr,
      type: type,
      blob: file,
      timestamp: Date.now()
    };

    await addPhoto(photoData);
    await loadPhotos();
  };

  const handleDelete = async (id) => {
    if (confirm('確定要刪除這張照片嗎？')) {
      await deletePhoto(id);
      await loadPhotos();
    }
  };

  const wearingPhoto = photos.find(p => p.type === 'wearing');
  const notWearingPhoto = photos.find(p => p.type === 'not-wearing');

  return (
    <div>
      <div className="header">
        <h1>牙套日記</h1>
      </div>

      <div className="card">
        <div className="status-grid">
          <div className="status-item">
            <div className="status-label">目前進度</div>
            <div className="status-value">第 {settings.currentCycle} 副</div>
          </div>
          <div className="status-item">
            <div className="status-label">距離複診</div>
            <div className="status-value">{diffDays > 0 ? `${diffDays} 天` : '今天/已過期'}</div>
          </div>
        </div>
      </div>

      <div className="card">
        <h3>今日紀錄 ({todayStr})</h3>

        <div className="photo-section">
          <div className="photo-entry">
            <h4>配戴中</h4>
            {wearingPhoto ? (
              <div>
                <img src={URL.createObjectURL(wearingPhoto.blob)} className="photo-preview" alt="wearing" />
                <button className="btn btn-danger" style={{ marginTop: '10px' }} onClick={() => handleDelete(wearingPhoto.id)}>刪除</button>
              </div>
            ) : (
              <label className="photo-placeholder">
                <input type="file" accept="image/*" onChange={(e) => handleFileUpload(e, 'wearing')} />
                點擊上傳「配戴中」照片
              </label>
            )}
          </div>

          <div className="photo-entry">
            <h4>未配戴</h4>
            {notWearingPhoto ? (
              <div>
                <img src={URL.createObjectURL(notWearingPhoto.blob)} className="photo-preview" alt="not wearing" />
                <button className="btn btn-danger" style={{ marginTop: '10px' }} onClick={() => handleDelete(notWearingPhoto.id)}>刪除</button>
              </div>
            ) : (
              <label className="photo-placeholder">
                <input type="file" accept="image/*" onChange={(e) => handleFileUpload(e, 'not-wearing')} />
                點擊上傳「未配戴」照片
              </label>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function HistoryView() {
  const [history, setHistory] = useState([]);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    const allPhotos = await getAllPhotos();
    // Group by date
    const groups = {};
    allPhotos.forEach(p => {
      if (!groups[p.date]) groups[p.date] = [];
      groups[p.date].push(p);
    });

    // Sort dates desc
    const sortedDates = Object.keys(groups).sort((a, b) => new Date(b) - new Date(a));
    const historyData = sortedDates.map(date => ({
      date,
      photos: groups[date]
    }));
    setHistory(historyData);
  };

  return (
    <div>
      <div className="header">
        <h1>歷史紀錄</h1>
      </div>
      {history.length === 0 ? (
        <div className="card">
          <p style={{ textAlign: 'center' }}>尚無歷史紀錄</p>
        </div>
      ) : (
        history.map(item => (
          <div key={item.date} className="card">
            <h3>{item.date}</h3>
            <div className="status-grid">
              {item.photos.map(p => (
                <div key={p.id} className="status-item">
                  <div className="status-label">{p.type === 'wearing' ? '配戴中' : '未配戴'}</div>
                  <img src={URL.createObjectURL(p.blob)} style={{ width: '100%', borderRadius: '8px', height: '100px', objectFit: 'cover' }} />
                </div>
              ))}
            </div>
          </div>
        ))
      )}
    </div>
  );
}

function SettingsView({ settings }) {
  const handleExport = async () => {
    // Export Settings + Photos
    const allPhotos = await getAllPhotos();
    // Convert Blobs to Base64 for JSON export is heavy, but doable for backups.
    // Ideally use Zip but for simplicity JSON with Base64.
    const photosBase64 = await Promise.all(allPhotos.map(async (p) => {
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve({ ...p, blob: reader.result }); // result is base64 string
        reader.readAsDataURL(p.blob);
      });
    }));

    const backup = {
      settings: settings,
      photos: photosBase64,
      version: 1,
      exportDate: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(backup)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `aligner-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  const handleImport = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const backup = JSON.parse(event.target.result);
        if (backup.settings) {
          // Restore settings
          for (const [key, value] of Object.entries(backup.settings)) {
            await saveSetting(key, value);
          }
        }
        if (backup.photos) {
          // Restore photos
          // clear old photos? Maybe not, just add.
          // But to avoid duplicates might need logic. For now just add.
          // Need to convert Base64 back to Blob.
          for (const p of backup.photos) {
            const res = await fetch(p.blob);
            const blob = await res.blob();
            // Check if exists? Skip for now, IndexedDB auto-increment ID handles it, 
            // but we want to avoid double entries for same day/type.
            // Simple check:
            const existing = await getPhotosByDate(p.date);
            const alreadyExists = existing.find(e => e.type === p.type);
            if (!alreadyExists) {
              await addPhoto({
                date: p.date,
                type: p.type,
                blob: blob,
                timestamp: p.timestamp
              });
            }
          }
        }
        alert('還原成功！請重新整理頁面。');
        window.location.reload();
      } catch (err) {
        console.error(err);
        alert('還原失敗，檔案格式可能錯誤');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div>
      <div className="header">
        <h1>設定與備份</h1>
      </div>
      <div className="card">
        <h3>資料備份</h3>
        <p>將所有紀錄匯出成檔案，以便更換裝置或備份使用。</p>
        <button className="btn" onClick={handleExport}>匯出備份 (JSON)</button>
      </div>

      <div className="card">
        <h3>資料還原</h3>
        <p>從備份檔案還原紀錄。</p>
        <label className="btn btn-secondary" style={{ display: 'block', textAlign: 'center' }}>
          選擇備份檔案
          <input type="file" accept=".json" onChange={handleImport} style={{ display: 'none' }} />
        </label>
        <p style={{ fontSize: '0.8rem', color: 'red', marginTop: '10px' }}>注意：還原後可能需要重新整理頁面。</p>
      </div>
    </div>
  );
}

export default App;
